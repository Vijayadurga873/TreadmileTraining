﻿using DotnetCoreWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetCoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly EmpDbContext context;
      public  EmployeeController(EmpDbContext context)
        {
            this.context = context;
        }
        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            return context.Emps.ToList();
        }
        [HttpGet("{id}")]
        public Employee Get(int id)
        {
            return context.Emps.Find(id);
        }
        [HttpPost]
        public Employee Post([FromBody] Employee emp)
        {
            context.Emps.Add(emp);
            context.SaveChanges();
            return emp;
        
        }
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Employee emp)
        {
            context.Emps.Update(emp);
            context.SaveChanges();
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var emp = context.Emps.Find(id);
            context.Emps.Remove(emp);
            context.SaveChanges();
        }
    }
}
