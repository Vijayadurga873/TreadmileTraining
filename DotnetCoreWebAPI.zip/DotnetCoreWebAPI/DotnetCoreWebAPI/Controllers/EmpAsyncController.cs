﻿using DotnetCoreWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotnetCoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpAsyncController : ControllerBase
    {
        private readonly EmpDbContext context;
        public EmpAsyncController(EmpDbContext context)
        {
            this.context = context;
        }
        [HttpGet]
        public async Task<IEnumerable<Employee> >Get()
        {
            return await context.Emps.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult> Get(int id)
        {
            Employee emp= await context.Emps.FindAsync(id);
            if (emp == null)
                return NotFound("EId not Found");
            return Ok(emp);
        }
        //Create
        [HttpPost]
        public async Task<Employee> Post([FromBody] Employee emp)
        {
            await context.Emps.AddAsync(emp);
            await context.SaveChangesAsync();
            return emp;
        }
        //update
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Employee emp)
        {
            if (id != emp.EID)
                return BadRequest($"Id {id} and EId {emp.EID} doesn't not matched"); //400 error
            var res =await context.Emps.FindAsync(id);
            if (res == null)
                return NotFound("Id not Found"); //404 error
            res.EName = emp.EName;
            res.ESal = emp.ESal;
           // context.Emps.Update(emp);
            await context.SaveChangesAsync();
            return Ok(emp);
        }

        // DELETE
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            Employee emp = context.Emps.Find(id);
            if (emp == null)
                return NotFound("Eid not Found"); //404 error
            context.Emps.Remove(emp);
            await context.SaveChangesAsync();
            return Ok();
        }
    }
}
