﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MongoAPI.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class empsController : ControllerBase
    {
        private readonly IMongoCollection<Emp> emps;
        public empsController(IConfiguration configuration)
        {
            MongoClient dbclient = new MongoClient(configuration.GetConnectionString("mydb"));
            IMongoDatabase db = dbclient.GetDatabase("Vijaya");
            emps = db.GetCollection<Emp>("emps");

        }
        [HttpGet]
        public List<Emp> Get()
        {
            return emps.AsQueryable().ToList();
        }
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var emp = emps.Find(e => e.id == id).FirstOrDefault();
            if (emp == null)
                return NotFound("Id doesn't exists!");
            return Ok(emp);
        }

        [HttpPost]
        public Emp Post(Emp emp)
        {
            emps.InsertOne(emp);
            return emp;
        }
        [HttpPut("{id}")]
        public IActionResult Put(int id,Emp emp )
        {
            if (id != emp.id)
                return NotFound($"Id {id} doesn't match with  empID {emp.id}");
            emps.ReplaceOne(e => e.id == id, emp);
            return Ok();
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var emp = emps.Find(e => e.id == id).FirstOrDefault();
            if (emp == null)
                return NotFound("Id doesn't exists!");
            return Ok(emps.DeleteOne(e => e.id == id));
        }
    }
}
