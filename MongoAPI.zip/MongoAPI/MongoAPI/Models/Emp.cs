﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;


namespace MongoAPI.Models
{
    public class Emp
    {
            [BsonId]
            [BsonRepresentation(BsonType.ObjectId)]
            public string _id { get; set; }

            public int id { get; set; }
            public string name { get; set; }
            public string gender { get; set; }
            public int sal { get; set; }
    }
}




