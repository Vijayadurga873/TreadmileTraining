﻿using System;
using System.Threading.Tasks;
using StackExchange.Redis;

namespace RedisDemo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            using (var cache = ConnectionMultiplexer.Connect("localhost"))
            {
                IDatabase db = cache.GetDatabase();

                bool setValue = await db.StringSetAsync("abhishek:demokey", "100");
                Console.WriteLine($"SET: {setValue}");

                //string getValue = await db.StringGetAsync("abhishek:demokey");
                //Console.WriteLine($"GET: {getValue}");

                 //bool deleted = await db.KeyDeleteAsync("abhishek:demokey");
               // Console.WriteLine($"DELETED: {deleted}");

            }
        }
    }
}
